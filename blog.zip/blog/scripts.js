function addComment(postId) {
    const commentInput = document.getElementById(`commentInput${postId}`);
    const commentText = commentInput.value;
  
    if (commentText.trim() !== '') {
      const commentsContainer = document.getElementById(`comments${postId}`);
      const newComment = document.createElement('div');
      newComment.classList.add('comment');
      newComment.innerHTML = `<p>${commentText}</p><span>${getCurrentDate()}</span>`;
      commentsContainer.appendChild(newComment);
      commentInput.value = '';
    }
  }
  
  function getCurrentDate() {
    const currentDate = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return currentDate.toLocaleDateString('en-US', options);
  }
  function searchPosts() {
    const searchInput = document.getElementById('searchInput');
    const searchText = searchInput.value.toLowerCase();
    const blogPosts = document.querySelectorAll('.blog-post');
  
    blogPosts.forEach(post => {
      const title = post.querySelector('h2').innerText.toLowerCase();
      if (title.includes(searchText)) {
        post.style.display = 'block';
      } else {
        post.style.display = 'none';
      }
    });
  }
    